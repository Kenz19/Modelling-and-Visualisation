Open the IsingModel.py file and run this. The terminal will prompt for animation or measurements to be carried out. 

Prompts appropriate to this response will follow